#coding: utf-8

METHOD_GET = "GET"
METHOD_POST = "POST"

RES_HEADER_TTS_REQUEST_CHARACTERS = 'x-amzn-IvonaTtsRequestCharacters'
RES_HEADER_TTS_REQUEST_ID = 'x-amzn-IvonaTtsRequestId'
RES_HEADER_REQUEST_ID = 'x-amzn-RequestId'
